-- Instructors table
CREATE TABLE Instructors (
    ins_ID NUMBER PRIMARY KEY,
    ins_fname VARCHAR2(50),
    ins_sname VARCHAR2(50),
    ins_contact VARCHAR2(20),
    ins_level NUMBER
);

-- Customers table
CREATE TABLE Customers (
    cust_id VARCHAR2(10) PRIMARY KEY,
    cust_fname VARCHAR2(50),
    cust_sname VARCHAR2(50),
    cust_address VARCHAR2(100),
    cust_contact VARCHAR2(20)
);

-- Dives table
CREATE TABLE Dives (
    dive_ID NUMBER PRIMARY KEY,
    dive_name VARCHAR2(50),
    dive_duration VARCHAR2(20),
    dive_location VARCHAR2(50),
    dive_exp_level NUMBER,
    dive_cost NUMBER
);

-- Dive Events table
CREATE TABLE Dive_Events (
    dive_event_id VARCHAR2(10) PRIMARY KEY,
    dive_date DATE,
    dive_participants NUMBER,
    ins_ID NUMBER,
    cust_id VARCHAR2(10),
    dive_ID NUMBER,
    FOREIGN KEY (ins_ID) REFERENCES Instructors(ins_ID),
    FOREIGN KEY (cust_id) REFERENCES Customers(cust_id),
    FOREIGN KEY (dive_ID) REFERENCES Dives(dive_ID)
);


-- Inserting data into Instructors table
INSERT INTO Instructors (ins_ID, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (101, 'James', 'Willis', '0843569851', 7);

INSERT INTO Instructors (ins_ID, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (102, 'Sam', 'Wait', '0763698521', 2);

INSERT INTO Instructors (ins_ID, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (103, 'Sally', 'Gumede', '0786598521', 8);

INSERT INTO Instructors (ins_ID, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (104, 'Bob', 'Du Preez', '0796369857', 3);

INSERT INTO Instructors (ins_ID, ins_fname, ins_sname, ins_contact, ins_level)
VALUES (105, 'Simon', 'Jones', '0826598741', 9);

-- Inserting data into Customers table
INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C115', 'Heinrich', 'Willis', '3 Main Road', '0821253659');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C116', 'David', 'Watson', '13 Cape Road', '0769658547');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C117', 'Waldo', 'Smith', '3 Mountain Road', '0863256574');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C118', 'Alex', 'Hanson', '8 Circle Road', '0762356587');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C119', 'Kuhle', 'Bitterhout', '15 Main Road', '0821235258');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C120', 'Thando', 'Zolani', '88 Summer Road', '0847541254');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C121', 'Philip', 'Jackson', '3 Long Road', '0745556658');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C122', 'Sarah', 'Jones', '7 Sea Road', '0814745745');

INSERT INTO Customers (cust_id, cust_fname, cust_sname, cust_address, cust_contact)
VALUES ('C123', 'Catherine', 'Howard', '31 Lake Side Road', '0822232521');

-- Inserting data into Dives table
INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (550, 'Shark Dive', '3 hours', 'Shark Point', 8, 500);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (551, 'Coral Dive', '1 hour', 'Break Point', 7, 300);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (552, 'Wave', '2 hours', 'Ship wreck ally', 3, 800);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (553, 'Underwater Exploration', '1 hour', 'Coral ally', 2, 250);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (554, 'Underwater Adventure', '3 hours', 'Sandy Beach', 3, 750);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (555, 'Deep Blue Ocean', '30 minutes', 'Lazy Waves', 2, 120);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (556, 'Rough Seas', '1 hour', 'Pipe', 9, 700);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (557, 'White Water Drifts', '2 hours', 'Drifts', 5, 200);

INSERT INTO Dives (dive_ID, dive_name, dive_duration, dive_location, dive_exp_level, dive_cost)
VALUES (558, 'Current Adventure', '2 hours', 'Rock Lands', 3, 150);

-- Inserting data into Dive_Events table
INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_101', TO_DATE('15-Jul-17', 'DD-Mon-YY'), 5, 103, 'C115', 558);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_102', TO_DATE('16-Jul-17', 'DD-Mon-YY'), 7, 102, 'C117', 555);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_103', TO_DATE('18-Jul-17', 'DD-Mon-YY'), 8, 104, 'C118', 552);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_104', TO_DATE('19-Jul-17', 'DD-Mon-YY'), 3, 101, 'C119', 551);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_105', TO_DATE('21-Jul-17', 'DD-Mon-YY'), 5, 104, 'C121', 558);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_106', TO_DATE('22-Jul-17', 'DD-Mon-YY'), 8, 105, 'C120', 556);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_107', TO_DATE('25-Jul-17', 'DD-Mon-YY'), 10, 105, 'C115', 554);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_108', TO_DATE('27-Jul-17', 'DD-Mon-YY'), 5, 101, 'C122', 552);

INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
VALUES ('de_109', TO_DATE('28-Jul-17', 'DD-Mon-YY'), 3, 102, 'C123', 553);

--Q3
SELECT 
    i.ins_fname || ' ' || i.ins_sname AS INSTRUCTOR,
    c.cust_fname || ' ' || c.cust_sname AS CUSTOMER,
    d.dive_location AS DIVE_LOCATION,
    de.dive_participants AS DIVE_PARTICIPANTS
FROM 
    Dive_Events de
INNER JOIN 
    Instructors i ON de.ins_ID = i.ins_ID
INNER JOIN 
    Customers c ON de.cust_id = c.cust_id
INNER JOIN 
    Dives d ON de.dive_ID = d.dive_ID
WHERE 
    de.dive_participants BETWEEN 8 AND 10;
    
    --q4
    SET SERVEROUTPUT ON;
DECLARE
    CURSOR dive_events_cursor IS
        SELECT d.dive_name, e.dive_date, e.dive_participants
        FROM Dive_Events e
        JOIN Dives d ON e.dive_ID = d.dive_ID
        WHERE e.dive_participants >= 10;
        
    dive_name Dives.dive_name%TYPE;
    dive_date Dive_Events.dive_date%TYPE;
    participants Dive_Events.dive_participants%TYPE;
BEGIN
    FOR dive_event IN dive_events_cursor LOOP
        dive_name := dive_event.dive_name;
        dive_date := dive_event.dive_date;
        participants := dive_event.dive_participants;
        
        DBMS_OUTPUT.PUT_LINE('DIVE NAME : ' || dive_name);
        DBMS_OUTPUT.PUT_LINE('DIVE DATE : ' || TO_CHAR(dive_date, 'DD/MON/YY'));
        DBMS_OUTPUT.PUT_LINE('PARTICIPANTS : ' || participants);
        DBMS_OUTPUT.PUT_LINE('-----------------------------------------------');
    END LOOP;
END;
/

--Q5
SET SERVEROUTPUT ON;
DECLARE
    CURSOR dive_events_cursor IS
        SELECT c.cust_fname || ', ' || c.cust_sname AS customer_full_name,
               d.dive_name,
               e.dive_participants,
               d.dive_cost
        FROM Dive_Events e
        JOIN Customers c ON e.cust_id = c.cust_id
        JOIN Dives d ON e.dive_ID = d.dive_ID
        WHERE d.dive_cost > 500;

    customer_full_name VARCHAR2(100);
    dive_name VARCHAR2(50);
    dive_participants NUMBER;
    instructors_required NUMBER;
    dive_events_count NUMBER;
BEGIN
    OPEN dive_events_cursor;
    dive_events_count := dive_events_cursor%ROWCOUNT;

    LOOP
        FETCH dive_events_cursor INTO customer_full_name, dive_name, dive_participants, instructors_required;
        EXIT WHEN dive_events_cursor%NOTFOUND;

        -- Assuming a rule that one instructor is required for every 3 participants
        instructors_required := CEIL(dive_participants / 3);

        DBMS_OUTPUT.PUT_LINE('CUSTOMER : ' || customer_full_name);
        DBMS_OUTPUT.PUT_LINE('DIVE NAME : ' || dive_name);
        DBMS_OUTPUT.PUT_LINE('PARTICIPANTS : ' || dive_participants);
        DBMS_OUTPUT.PUT_LINE('STATUS : ' || instructors_required || ' instructors required.');
        DBMS_OUTPUT.PUT_LINE('------------------------------------------------------');
    END LOOP;

    CLOSE dive_events_cursor;
END;
/
--q6
CREATE OR REPLACE VIEW Vw_Dive_Event AS
SELECT 
    e.ins_ID,
    e.cust_id,
    c.cust_address,
    d.dive_duration,
    e.dive_date
FROM 
    Dive_Events e
JOIN 
    Customers c ON e.cust_id = c.cust_id
JOIN 
    Dives d ON e.dive_ID = d.dive_ID
WHERE 
    e.dive_date < TO_DATE('19-Jul-17', 'DD-Mon-YY')
    AND e.ins_ID NOT IN (102, 103);


SELECT * FROM Vw_Dive_Event;

--q7
CREATE OR REPLACE TRIGGER New_Dive_Event
BEFORE INSERT OR UPDATE ON Dive_Events
FOR EACH ROW
BEGIN
    IF :NEW.dive_participants <= 0 OR :NEW.dive_participants > 20 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Number of participants must be between 1 and 20.');
    END IF;
END;
/
-- Test Case 1: Insert with 0 participants (should fail)
BEGIN
    INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
    VALUES ('de_110', TO_DATE('15-Aug-17', 'DD-Mon-YY'), 0, 101, 'C115', 558);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

-- Test Case 2: Insert with 25 participants (should fail)
BEGIN
    INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
    VALUES ('de_111', TO_DATE('16-Aug-17', 'DD-Mon-YY'), 25, 102, 'C117', 555);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

-- Test Case 3: Insert with 5 participants (should succeed)
BEGIN
    INSERT INTO Dive_Events (dive_event_id, dive_date, dive_participants, ins_ID, cust_id, dive_ID)
    VALUES ('de_112', TO_DATE('17-Aug-17', 'DD-Mon-YY'), 5, 103, 'C118', 552);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

-- Test Case 4: Update to 0 participants (should fail)
BEGIN
    UPDATE Dive_Events
    SET dive_participants = 0
    WHERE dive_event_id = 'de_101';
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

-- Test Case 5: Update to 15 participants (should succeed)
BEGIN
    UPDATE Dive_Events
    SET dive_participants = 15
    WHERE dive_event_id = 'de_101';
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

--Q8
CREATE OR REPLACE PROCEDURE sp_Customer_Details(
    p_cust_id IN VARCHAR2,
    p_dive_date IN DATE
)
IS
    v_customer_name VARCHAR2(100);
    v_dive_name VARCHAR2(50);
    v_dive_date DATE;
BEGIN
    -- Retrieve customer details and dive information based on provided parameters
    SELECT c.cust_fname || ' ' || c.cust_sname,
           d.dive_name,
           de.dive_date
    INTO v_customer_name, v_dive_name, v_dive_date
    FROM Customers c
    JOIN Dive_Events de ON c.cust_id = de.cust_id
    JOIN Dives d ON de.dive_ID = d.dive_ID
    WHERE c.cust_id = p_cust_id
    AND TRUNC(de.dive_date) = TRUNC(p_dive_date);

    -- Display the result
    DBMS_OUTPUT.PUT_LINE('CUSTOMER DETAILS: ' || v_customer_name || ' booked for ' || v_dive_name || ' on ' || TO_CHAR(v_dive_date, 'DD/MON/YY'));

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No customer found for the provided ID and dive date.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/
BEGIN
    sp_Customer_Details('C115', TO_DATE('15-JUL-17', 'DD-MON-YY'));
END;
/

--Q9
-- Create or replace the function
CREATE OR REPLACE FUNCTION fn_TotalRevenueByInstructor(
    p_ins_ID IN NUMBER
)
RETURN NUMBER
IS
    v_total_revenue NUMBER := 0;
BEGIN
    -- Calculate total revenue from dive events for the given instructor ID
    SELECT SUM(d.dive_cost)
    INTO v_total_revenue
    FROM Dive_Events de
    JOIN Dives d ON de.dive_ID = d.dive_ID
    WHERE de.ins_ID = p_ins_ID;

    -- If no revenue found, set to 0
    IF v_total_revenue IS NULL THEN
        v_total_revenue := 0;
    END IF;

    RETURN v_total_revenue;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- Handle case where no dive events found for the instructor
        DBMS_OUTPUT.PUT_LINE('No dive events found for the instructor ID: ' || p_ins_ID);
        RETURN 0; -- Return 0 in case of no data found
    WHEN OTHERS THEN
        -- Handle any other exceptions
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        RETURN NULL; -- Return null in case of any other exception
END;
/

---
-- Declare a variable to hold the result
DECLARE
    v_result NUMBER;
BEGIN
    -- Call the function with input parameter
    v_result := fn_TotalRevenueByInstructor(103);
    
    -- Display the result
    DBMS_OUTPUT.PUT_LINE('Total revenue generated by instructor ID 103: R' || v_result);
END;
/

--Q10
BEGIN
    sp_Customer_Details('C115', TO_DATE('15-JUL-17', 'DD-MON-YY'));
END;
/



